# Support Mail

{{$name}}
 
<br>
 
{{$phone}}
<br>
{{$email}}
<br>
{{$supportoption}}
<br>
{{$usermessage}}
<br>
 


<div style="color:red">
 You have a new mail
</div>

 

Regards,<br>
{{ config('app.name') }}