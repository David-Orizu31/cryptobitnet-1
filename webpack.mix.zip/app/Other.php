<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Other extends Model
{
    protected $fillable = [
        'name',
        'email',
        'word',
     
      

    ];

}
